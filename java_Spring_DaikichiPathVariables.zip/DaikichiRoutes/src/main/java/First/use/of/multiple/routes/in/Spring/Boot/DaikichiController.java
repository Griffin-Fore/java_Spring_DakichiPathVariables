package First.use.of.multiple.routes.in.Spring.Boot;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/daikichi")
public class DaikichiController {

	@RequestMapping("")
	public String index() {
		return "Welcome";
	}

	@RequestMapping("/search")
	public String searchPage(@RequestParam(value = "q", required = false) String searchQuery) {
		if (searchQuery == null) {
			return "You searched for nothing";
		}
		return "You searched for: " + searchQuery;
	}

	@RequestMapping("/today")
	public String todayPage() {
		return "Today you will find luck in all your endeavors!";
	}

	@RequestMapping("/tomorrow")
	public String tomorrowPage() {
		return "Tomorrow, an opportunity will arise, so be sure to be open to new ideas!";
	}
	
	@RequestMapping("/travel/{city}")
	public String travelToCity(@PathVariable("city") String city) {
		return "Congratulations! You will soon travel to " + city;
	}
	
	@RequestMapping("/lotto/{lottoNumber}")
	public String lottery(@PathVariable("lottoNumber") int lottoNumber) {
		if(lottoNumber % 2 == 0) {
			return "You will take a grand journey in the near future, "
					+ "but be weary of tempting offers.";
		}
		else {
			return "You have enjoyed the fruits of your labor but now "
					+ "is a great time to spend time with family and friends.";
		}
	}
}
